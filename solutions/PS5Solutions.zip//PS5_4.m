%Lotanna Ezenwa, Problem Set 5, #3
%PS5_4.m
%% Due Wednesday, April 27th, 2016



clear
me = LotaEzenwa();
code = me.id; 


PS_5_4

5.5543*cos(3.3779) + i*sin(3.3779)*5.5543
5.5543*cos(-2.9053) + i*sin(-2.9053)*5.5543

